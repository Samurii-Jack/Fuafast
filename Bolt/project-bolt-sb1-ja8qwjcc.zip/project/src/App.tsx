import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import Subscriptions from './components/Subscriptions';
import HowItWorks from './components/HowItWorks';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import StickyWhatsAppButton from './components/StickyWhatsAppButton';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <Hero />
      <Services />
      <Subscriptions />
      <HowItWorks />
      <Testimonials />
      <Contact />
      <StickyWhatsAppButton />
    </div>
  );
}

export default App;
