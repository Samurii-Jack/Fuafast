import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.querySelector(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-lg shadow-lg py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="text-2xl lg:text-3xl font-black">
              <span className="text-orange-500">fua</span>
              <span className="text-blue-600">fast</span>
            </div>
          </div>

          <div className="hidden lg:flex items-center gap-8">
            <button
              onClick={() => scrollToSection('#services')}
              className={`font-semibold transition-colors ${
                isScrolled ? 'text-gray-700 hover:text-blue-600' : 'text-gray-800 hover:text-blue-600'
              }`}
            >
              Services
            </button>
            <button
              onClick={() => scrollToSection('#subscriptions')}
              className={`font-semibold transition-colors ${
                isScrolled ? 'text-gray-700 hover:text-blue-600' : 'text-gray-800 hover:text-blue-600'
              }`}
            >
              Plans
            </button>
            <button
              onClick={() => scrollToSection('#how-it-works')}
              className={`font-semibold transition-colors ${
                isScrolled ? 'text-gray-700 hover:text-blue-600' : 'text-gray-800 hover:text-blue-600'
              }`}
            >
              How It Works
            </button>
          </div>

          <div className="flex items-center gap-4">
            <a
              href="https://wa.me/254700000000?text=Habari!%20Nataka%20kufua%20nguo%20zangu."
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-bold rounded-xl hover:shadow-lg hover:scale-105 transition-all"
            >
              Book Now
            </a>

            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {isMobileMenuOpen && (
          <div className="lg:hidden mt-4 py-4 border-t border-gray-200 animate-fade-in">
            <div className="flex flex-col gap-4">
              <button
                onClick={() => scrollToSection('#services')}
                className="text-left font-semibold text-gray-700 hover:text-blue-600 transition-colors py-2"
              >
                Services
              </button>
              <button
                onClick={() => scrollToSection('#subscriptions')}
                className="text-left font-semibold text-gray-700 hover:text-blue-600 transition-colors py-2"
              >
                Plans
              </button>
              <button
                onClick={() => scrollToSection('#how-it-works')}
                className="text-left font-semibold text-gray-700 hover:text-blue-600 transition-colors py-2"
              >
                How It Works
              </button>
              <a
                href="https://wa.me/254700000000?text=Habari!%20Nataka%20kufua%20nguo%20zangu."
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-bold rounded-xl hover:shadow-lg transition-all"
              >
                Book Now
              </a>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
