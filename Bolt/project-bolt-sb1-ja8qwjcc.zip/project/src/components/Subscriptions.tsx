import { Check, Star } from 'lucide-react';

export default function Subscriptions() {
  const plans = [
    {
      name: "Solo Dweller",
      kg: "20 kg",
      price: "2,070",
      originalPrice: "2,300",
      savings: "230",
      perks: ["Free pickup & delivery", "Branded packaging", "Flexible scheduling"],
      popular: false,
    },
    {
      name: "Couple's Plan",
      kg: "40 kg",
      price: "3,910",
      originalPrice: "4,600",
      savings: "690",
      perks: ["Priority scheduling", "Free delivery", "Dedicated support", "Same-day available"],
      popular: true,
    },
    {
      name: "Family Bundle",
      kg: "60 kg",
      price: "5,520",
      originalPrice: "6,900",
      savings: "1,380",
      perks: ["VIP support 24/7", "Top priority", "Express available", "Custom requests"],
      popular: false,
    },
  ];

  return (
    <section id="subscriptions" className="py-20 lg:py-32 bg-gradient-to-br from-gray-50 to-blue-50 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,rgba(65,99,255,0.08)_0%,transparent_50%)]" />

      <div className="container mx-auto px-4 relative">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 space-y-4 animate-fade-in-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-blue-200 shadow-sm">
              <span className="text-2xl">📅</span>
              <span className="text-sm font-bold text-blue-600">Monthly Plans</span>
            </div>
            <h2 className="text-4xl lg:text-5xl font-black text-gray-900">
              Subscribe & Save Big
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Recurring laundry, recurring peace of mind. Save up to 20% with monthly plans.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {plans.map((plan, index) => (
              <div
                key={index}
                className={`relative bg-white rounded-3xl p-8 transition-all duration-500 hover:-translate-y-2 animate-fade-in-up ${
                  plan.popular
                    ? 'border-4 border-blue-500 shadow-2xl shadow-blue-500/20 scale-105'
                    : 'border-2 border-gray-200 hover:border-blue-300 shadow-lg'
                }`}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-2 rounded-full font-bold text-sm flex items-center gap-2 shadow-lg">
                    <Star className="w-4 h-4 fill-current" />
                    Most Popular
                  </div>
                )}

                <div className="space-y-6">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">
                      {plan.name}
                    </h3>
                    <p className="text-lg text-gray-600 font-medium">{plan.kg} / month</p>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-baseline gap-2">
                      <span className="text-5xl font-black text-gray-900">
                        KSh {plan.price}
                      </span>
                      <span className="text-lg text-gray-500">/mo</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-gray-400 line-through">
                        KSh {plan.originalPrice}
                      </span>
                      <span className="text-sm font-bold text-green-600 bg-green-50 px-2 py-1 rounded-full">
                        Save KSh {plan.savings}
                      </span>
                    </div>
                  </div>

                  <div className="h-px bg-gray-200" />

                  <ul className="space-y-3">
                    {plan.perks.map((perk, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
                          plan.popular ? 'bg-blue-500' : 'bg-gray-200'
                        }`}>
                          <Check className={`w-3 h-3 ${plan.popular ? 'text-white' : 'text-gray-600'}`} />
                        </div>
                        <span className="text-sm text-gray-700 font-medium">{perk}</span>
                      </li>
                    ))}
                  </ul>

                  <a
                    href={`https://wa.me/254700000000?text=${encodeURIComponent(`I want to subscribe to ${plan.name}`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`block w-full text-center py-4 font-bold rounded-xl transition-all ${
                      plan.popular
                        ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-lg hover:shadow-xl'
                        : 'bg-gray-900 text-white hover:bg-gray-800'
                    }`}
                  >
                    Subscribe Now
                  </a>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-2xl p-8 text-center text-white shadow-xl animate-fade-in-up">
            <p className="text-2xl font-bold mb-2">
              Save up to 20% + Get Priority Scheduling!
            </p>
            <p className="text-green-100">
              Cancel anytime. No commitments. Just clean clothes delivered on time, every time.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
