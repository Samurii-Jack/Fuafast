import { Phone, MapPin, MessageCircle, Mail } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="py-20 lg:py-32 bg-gray-900 text-white relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(65,99,255,0.1)_0%,transparent_50%),radial-gradient(circle_at_70%_80%,rgba(255,107,53,0.1)_0%,transparent_50%)]" />

      <div className="container mx-auto px-4 relative">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 space-y-4 animate-fade-in-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full border border-white/20">
              <span className="text-2xl">📍</span>
              <span className="text-sm font-bold">Get in Touch</span>
            </div>
            <h2 className="text-4xl lg:text-5xl font-black">
              Ready to Relax?
            </h2>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Book your first pickup in 30 seconds. We're here to help.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            <a
              href="https://wa.me/254700000000"
              target="_blank"
              rel="noopener noreferrer"
              className="group bg-white/5 backdrop-blur-sm border-2 border-white/10 rounded-2xl p-6 hover:bg-green-500 hover:border-green-500 transition-all duration-300 animate-fade-in-up"
            >
              <MessageCircle className="w-12 h-12 mb-4 text-green-400 group-hover:text-white transition-colors" />
              <h3 className="font-bold text-lg mb-2">WhatsApp</h3>
              <p className="text-sm text-gray-400 group-hover:text-white/90 transition-colors">
                Fastest way to book
              </p>
              <p className="text-xs text-gray-500 group-hover:text-white/70 mt-2">
                +254 700 000 000
              </p>
            </a>

            <a
              href="tel:+254700000000"
              className="group bg-white/5 backdrop-blur-sm border-2 border-white/10 rounded-2xl p-6 hover:bg-blue-500 hover:border-blue-500 transition-all duration-300 animate-fade-in-up"
              style={{ animationDelay: "100ms" }}
            >
              <Phone className="w-12 h-12 mb-4 text-blue-400 group-hover:text-white transition-colors" />
              <h3 className="font-bold text-lg mb-2">Call Us</h3>
              <p className="text-sm text-gray-400 group-hover:text-white/90 transition-colors">
                Talk to a human
              </p>
              <p className="text-xs text-gray-500 group-hover:text-white/70 mt-2">
                +254 700 000 000
              </p>
            </a>

            <div className="group bg-white/5 backdrop-blur-sm border-2 border-white/10 rounded-2xl p-6 hover:bg-orange-500 hover:border-orange-500 transition-all duration-300 animate-fade-in-up" style={{ animationDelay: "200ms" }}>
              <MapPin className="w-12 h-12 mb-4 text-orange-400 group-hover:text-white transition-colors" />
              <h3 className="font-bold text-lg mb-2">Visit Us</h3>
              <p className="text-sm text-gray-400 group-hover:text-white/90 transition-colors">
                Olepolos Centre
              </p>
              <p className="text-xs text-gray-500 group-hover:text-white/70 mt-2">
                Ngong, Kenya
              </p>
            </div>

            <div className="group bg-white/5 backdrop-blur-sm border-2 border-white/10 rounded-2xl p-6 hover:bg-purple-500 hover:border-purple-500 transition-all duration-300 animate-fade-in-up" style={{ animationDelay: "300ms" }}>
              <Mail className="w-12 h-12 mb-4 text-purple-400 group-hover:text-white transition-colors" />
              <h3 className="font-bold text-lg mb-2">Email</h3>
              <p className="text-sm text-gray-400 group-hover:text-white/90 transition-colors">
                For inquiries
              </p>
              <p className="text-xs text-gray-500 group-hover:text-white/70 mt-2">
                hello@fuafast.co.ke
              </p>
            </div>
          </div>

          <div className="bg-gradient-to-r from-blue-600 to-orange-600 rounded-3xl p-12 text-center shadow-2xl mb-16 animate-fade-in-up">
            <h3 className="text-3xl lg:text-4xl font-black mb-4">
              First Wash? Get 10% Off
            </h3>
            <p className="text-xl text-white/90 mb-6">
              Join 500+ happy customers in Ngong. Book your pickup now.
            </p>
            <a
              href="https://wa.me/254700000000?text=I%27m%20a%20first-time%20customer.%20I%20want%2010%25%20off!"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-blue-600 font-bold px-10 py-4 rounded-xl hover:shadow-2xl hover:scale-105 transition-all"
            >
              Claim Your Discount
            </a>
          </div>

          <footer className="border-t border-white/10 pt-12">
            <div className="grid md:grid-cols-3 gap-8 mb-12">
              <div className="space-y-4">
                <div className="text-4xl font-black">
                  <span className="text-orange-500">fua</span>
                  <span className="text-blue-500">fast</span>
                </div>
                <p className="text-2xl font-bold text-gray-300">
                  TULIA, TUTAKUFULIA.
                </p>
                <p className="text-sm text-gray-400">
                  Premium laundry service for busy professionals in Ngong, Kenya.
                </p>
              </div>

              <div>
                <h4 className="font-bold mb-4">Quick Links</h4>
                <ul className="space-y-2 text-sm text-gray-400">
                  <li><a href="#services" className="hover:text-white transition-colors">Services</a></li>
                  <li><a href="#subscriptions" className="hover:text-white transition-colors">Monthly Plans</a></li>
                  <li><a href="#how-it-works" className="hover:text-white transition-colors">How It Works</a></li>
                  <li><a href="#contact" className="hover:text-white transition-colors">Contact</a></li>
                </ul>
              </div>

              <div>
                <h4 className="font-bold mb-4">Service Areas</h4>
                <ul className="space-y-2 text-sm text-gray-400">
                  <li>Ngong Town</li>
                  <li>Olepolos & Hilltop</li>
                  <li>Zambia Road</li>
                  <li>Surrounding Areas</li>
                </ul>
              </div>
            </div>

            <div className="border-t border-white/10 pt-8 text-center text-sm text-gray-400">
              <p>&copy; 2026 FuaFast. All rights reserved. Made with 💙 in Ngong.</p>
            </div>
          </footer>
        </div>
      </div>
    </section>
  );
}
