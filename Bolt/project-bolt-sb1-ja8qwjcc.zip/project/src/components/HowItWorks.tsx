export default function HowItWorks() {
  const steps = [
    {
      num: "1",
      icon: "💬",
      title: "WhatsApp Us",
      desc: "Message us anytime. We respond in minutes.",
    },
    {
      num: "2",
      icon: "🚗",
      title: "Free Pickup",
      desc: "We come to your door at your preferred time.",
    },
    {
      num: "3",
      icon: "⚖️",
      title: "Weight Check",
      desc: "Accurate weighing on the spot, transparent pricing.",
    },
    {
      num: "4",
      icon: "🫧",
      title: "Premium Wash",
      desc: "Quality detergents, machine wash, perfect drying.",
    },
    {
      num: "5",
      icon: "👔",
      title: "Neat Folding",
      desc: "Hand-folded with care, organized by type.",
    },
    {
      num: "6",
      icon: "📦",
      title: "Eco Packaging",
      desc: "Branded bags that protect your clean clothes.",
    },
    {
      num: "7",
      icon: "🎉",
      title: "Fast Delivery",
      desc: "Back at your door in 24 hours. Guaranteed.",
    },
  ];

  return (
    <section id="how-it-works" className="py-20 lg:py-32 bg-white relative overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 space-y-4 animate-fade-in-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-orange-50 rounded-full border border-orange-200">
              <span className="text-2xl">🔄</span>
              <span className="text-sm font-bold text-orange-600">The Process</span>
            </div>
            <h2 className="text-4xl lg:text-5xl font-black text-gray-900">
              How It Works
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Seven simple steps from dirty laundry to fresh, folded clothes.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {steps.map((step, index) => (
              <div
                key={index}
                className="relative group animate-fade-in-up"
                style={{ animationDelay: `${index * 80}ms` }}
              >
                <div className="relative bg-gradient-to-br from-white to-gray-50 rounded-2xl p-6 border-2 border-gray-200 hover:border-blue-400 hover:shadow-xl transition-all duration-300 h-full">
                  <div className="absolute -top-4 -left-4 w-12 h-12 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center text-white font-black text-xl shadow-lg group-hover:scale-110 transition-transform">
                    {step.num}
                  </div>

                  <div className="mt-4 space-y-3">
                    <div className="text-5xl">{step.icon}</div>
                    <h3 className="text-xl font-bold text-gray-900">{step.title}</h3>
                    <p className="text-sm text-gray-600 leading-relaxed">{step.desc}</p>
                  </div>
                </div>

                {index < steps.length - 1 && index % 4 !== 3 && (
                  <div className="hidden lg:block absolute top-1/2 -right-3 w-6 h-0.5 bg-gradient-to-r from-blue-400 to-transparent" />
                )}
              </div>
            ))}
          </div>

          <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-3xl p-8 lg:p-12 text-white text-center shadow-2xl animate-fade-in-up">
            <div className="max-w-3xl mx-auto space-y-6">
              <div className="text-6xl">⏱️</div>
              <h3 className="text-3xl lg:text-4xl font-black">
                24-Hour Turnaround Guarantee
              </h3>
              <p className="text-xl text-blue-100">
                We pick up today, deliver tomorrow. Every single time. Or your next wash is on us.
              </p>
              <a
                href="https://wa.me/254700000000?text=Tell%20me%20more%20about%20your%2024hr%20guarantee"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block bg-white text-blue-600 font-bold px-8 py-4 rounded-xl hover:shadow-xl hover:scale-105 transition-all"
              >
                Book Your First Pickup
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
