import { Star } from 'lucide-react';

export default function Testimonials() {
  const testimonials = [
    {
      name: "Sarah M.",
      location: "Olepolos Centre",
      rating: 5,
      text: "FuaFast saved my life! No more weekend laundry stress. They pick up Monday, deliver Tuesday. My clothes smell amazing and are perfectly folded.",
      avatar: "SM",
    },
    {
      name: "David K.",
      location: "Hilltop Apartments",
      rating: 5,
      text: "Best decision ever. The sneaker cleaning is incredible - my white shoes look brand new. Professional service, fair pricing.",
      avatar: "DK",
    },
    {
      name: "Grace W.",
      location: "Zambia Road",
      rating: 5,
      text: "I was skeptical at first, but the quality is top-notch. They handle delicates with care and the packaging is so premium. Worth every shilling!",
      avatar: "GW",
    },
  ];

  const stats = [
    { number: "500+", label: "Happy Customers" },
    { number: "10,000+", label: "Loads Washed" },
    { number: "24hrs", label: "Average Turnaround" },
    { number: "4.9/5", label: "Customer Rating" },
  ];

  return (
    <section className="py-20 lg:py-32 bg-gradient-to-br from-blue-50 via-white to-orange-50 relative overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 space-y-4 animate-fade-in-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-blue-200 shadow-sm">
              <span className="text-2xl">💙</span>
              <span className="text-sm font-bold text-blue-600">Customer Love</span>
            </div>
            <h2 className="text-4xl lg:text-5xl font-black text-gray-900">
              Trusted by Your Neighbors
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Don't just take our word for it. Here's what Ngong residents are saying.
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8 mb-16">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl p-6 text-center border-2 border-gray-200 hover:border-blue-400 hover:shadow-lg transition-all animate-fade-in-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="text-4xl font-black bg-gradient-to-r from-blue-600 to-blue-800 bg-clip-text text-transparent mb-2">
                  {stat.number}
                </div>
                <div className="text-sm text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl p-8 border-2 border-gray-200 hover:border-blue-400 hover:shadow-xl transition-all duration-300 animate-fade-in-up"
                style={{ animationDelay: `${index * 150}ms` }}
              >
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                    {testimonial.avatar}
                  </div>
                  <div>
                    <p className="font-bold text-gray-900">{testimonial.name}</p>
                    <p className="text-sm text-gray-500">{testimonial.location}</p>
                  </div>
                </div>

                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>

                <p className="text-gray-700 leading-relaxed">"{testimonial.text}"</p>
              </div>
            ))}
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white rounded-2xl p-6 border-2 border-green-200 text-center animate-fade-in-up">
              <div className="text-4xl mb-3">✅</div>
              <h3 className="font-bold text-gray-900 mb-2">Damage-Free Guarantee</h3>
              <p className="text-sm text-gray-600">
                If we damage it, we replace it. No questions asked.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 border-2 border-blue-200 text-center animate-fade-in-up" style={{ animationDelay: "100ms" }}>
              <div className="text-4xl mb-3">🧼</div>
              <h3 className="font-bold text-gray-900 mb-2">Premium Detergents</h3>
              <p className="text-sm text-gray-600">
                We use only quality, fabric-safe cleaning products.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 border-2 border-orange-200 text-center animate-fade-in-up" style={{ animationDelay: "200ms" }}>
              <div className="text-4xl mb-3">🔒</div>
              <h3 className="font-bold text-gray-900 mb-2">Secure & Hygienic</h3>
              <p className="text-sm text-gray-600">
                Clean facilities, masked staff, contactless service.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
