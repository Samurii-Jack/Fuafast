export default function Services() {
  const services = [
    {
      icon: "🫧",
      name: "Wash · Dry · Fold",
      price: "115",
      unit: "kg",
      note: "6 kg minimum order",
      color: "blue",
      gradient: "from-blue-500 to-blue-600",
      bg: "bg-blue-50",
      border: "border-blue-200",
    },
    {
      icon: "🚀",
      name: "Same-Day Express",
      price: "165",
      unit: "kg",
      note: "Order by 9 AM → Back by 2 PM",
      badge: "Express",
      color: "orange",
      gradient: "from-orange-500 to-orange-600",
      bg: "bg-orange-50",
      border: "border-orange-200",
    },
    {
      icon: "👟",
      name: "Sneaker Lab",
      price: "240",
      unit: "pair",
      note: "Deep clean & whitening",
      color: "green",
      gradient: "from-green-500 to-green-600",
      bg: "bg-green-50",
      border: "border-green-200",
    },
  ];

  return (
    <section id="services" className="py-20 lg:py-32 bg-white relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-orange-500 to-green-500" />

      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 space-y-4 animate-fade-in-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-50 rounded-full border border-blue-200">
              <span className="text-2xl">💧</span>
              <span className="text-sm font-bold text-blue-600">Service Menu</span>
            </div>
            <h2 className="text-4xl lg:text-5xl font-black text-gray-900">
              What We Do Best
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Premium quality at pilot prices. Every garment treated with care.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div
                key={index}
                className={`group relative ${service.bg} ${service.border} border-2 rounded-3xl p-8 hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 animate-fade-in-up`}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                {service.badge && (
                  <div className="absolute -top-3 -right-3 bg-gradient-to-r from-yellow-400 to-orange-500 text-white text-xs font-bold px-4 py-2 rounded-full shadow-lg rotate-12 animate-pulse">
                    ⚡ {service.badge}
                  </div>
                )}

                <div className="space-y-6">
                  <div className={`w-20 h-20 bg-gradient-to-br ${service.gradient} rounded-2xl flex items-center justify-center text-4xl shadow-lg group-hover:scale-110 group-hover:rotate-12 transition-transform duration-500`}>
                    {service.icon}
                  </div>

                  <div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">
                      {service.name}
                    </h3>
                    <div className="flex items-baseline gap-2">
                      <span className="text-4xl font-black text-gray-900">
                        KSh {service.price}
                      </span>
                      <span className="text-lg text-gray-500">/ {service.unit}</span>
                    </div>
                  </div>

                  <div className={`p-4 bg-white rounded-xl border ${service.border}`}>
                    <p className="text-sm text-gray-600 font-medium">
                      {service.note}
                    </p>
                  </div>

                  <div className="pt-4">
                    <a
                      href={`https://wa.me/254700000000?text=${encodeURIComponent(`I want to book ${service.name}`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`block w-full text-center py-3 bg-gradient-to-r ${service.gradient} text-white font-bold rounded-xl hover:shadow-lg transition-shadow`}
                    >
                      Book Now
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center p-6 bg-gradient-to-r from-blue-50 to-orange-50 rounded-2xl border border-blue-200">
            <p className="text-gray-700 font-medium">
              <span className="font-bold text-blue-600">First-time customer?</span> Get 10% off your first order. Just mention this offer on WhatsApp!
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
